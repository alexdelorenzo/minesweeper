`{{ objname }}`
==============================================================

.. template function.rst

Function defined in ``{{ module }}``

.. auto{{ objtype }}:: {{ fullname }}

